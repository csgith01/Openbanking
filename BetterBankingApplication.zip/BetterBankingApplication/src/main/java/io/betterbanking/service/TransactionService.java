package io.betterbanking.service;

import io.betterbanking.entity.Transaction;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Date;
import java.util.List;

@Service
public class TransactionService {

    public  static List<Transaction> listOfTransactions = new ArrayList<Transaction>();


    private static void addTransaction (Transaction transaction) {

        listOfTransactions.add(transaction);
    }

    public static List findAllByAccountNumber(DecimalFormat accountNumber) {

        Transaction transaction = new Transaction('C', new Date(), new DecimalFormat("1234567980"),  Currency.getInstance("USD"), new BigDecimal("100.50"), "OpenMerchantLogo", "OpenMerchantLogo" );
        addTransaction(transaction);

        return listOfTransactions;
    }
}