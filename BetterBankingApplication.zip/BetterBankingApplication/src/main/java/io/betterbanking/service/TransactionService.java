package io.betterbanking.service;

import io.betterbanking.entity.Transaction;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

@Component
public class TransactionService {

    public static List<Transaction> listOfTransactions = new ArrayList<Transaction>();


    public void addTransaction (Transaction transaction) {

        listOfTransactions.add(transaction);
    }

    public static List findAllByAccountNumber(DecimalFormat accountNumber) {

        return listOfTransactions;
    }
}