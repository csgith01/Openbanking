package io.betterbanking.web;

import io.betterbanking.service.TransactionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.text.DecimalFormat;

@RestController
@RequestMapping(value="/transactions", produces = MediaType.APPLICATION_JSON_VALUE)
public class TransactionController {


    private TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {

        this.transactionService = transactionService;
    }

    public TransactionController() {

    }

    @GetMapping("/{accountNumber}")
    public @ResponseBody TransactionService findAllByAccountNumber(@PathVariable DecimalFormat accountNumber) {
        return (TransactionService) TransactionService.findAllByAccountNumber(accountNumber);
    }

}