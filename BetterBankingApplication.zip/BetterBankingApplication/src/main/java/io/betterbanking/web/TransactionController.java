package io.betterbanking.web;

import io.betterbanking.service.TransactionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.text.DecimalFormat;
import java.util.List;

@RestController
@RequestMapping(value="/transactions", produces = MediaType.APPLICATION_JSON_VALUE)
public class TransactionController {

    @Autowired
    private TransactionService transactionService;


    public TransactionController(final TransactionService transactionService) {

        this.transactionService = transactionService;
    }

 // public TransactionController() {



 //   }

    @GetMapping("/{accountNumber}")
    public List findAllByAccountNumber(@PathVariable("accountNumber") DecimalFormat accountNumber) {
        return  TransactionService.findAllByAccountNumber(accountNumber);
    }

}