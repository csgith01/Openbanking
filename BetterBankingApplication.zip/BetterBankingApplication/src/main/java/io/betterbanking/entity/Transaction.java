package io.betterbanking.entity;

import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Currency;
import java.util.Date;

public class Transaction {

    char type;
    Date date;
    DecimalFormat accountNumber;
    Currency currency;
    BigDecimal amount;
    String merchantName;
    BufferedImage merchantLogo;

}
