package io.betterbanking.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Currency;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Transaction {

    char type;
    Date date;
    DecimalFormat accountNumber;
    Currency currency;
    BigDecimal amount;
    String merchantName;
    String merchantLogo;

}
