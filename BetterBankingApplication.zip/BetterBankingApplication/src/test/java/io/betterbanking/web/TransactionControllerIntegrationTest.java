package io.betterbanking.web;

import io.betterbanking.service.TransactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ArgumentsSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.*;

@WebMvcTest(TransactionController.class)
class TransactionControllerIntegrationTest {

    @MockBean
    private TransactionService transactionService;

 //   TransactionControllerIntegrationTest(TransactionService transactionService) {
 //       this.transactionService = transactionService;

 //   }


    @Autowired
    private WebApplicationContext webContext;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setUpMockMvc() {

        this.mockMvc = MockMvcBuilders.webAppContextSetup(webContext).build();
    }

    @Test
     void mockMvcExists() {
        assertNotNull(mockMvc);
        assertNotNull(transactionService);
    }


}