package io.service;

import io.betterbanking.service.TransactionService;
import org.junit.jupiter.api.Test;

import java.text.DecimalFormat;

import static org.junit.jupiter.api.Assertions.*;

class TransactionServiceTest {

    TransactionService transactionService = new TransactionService();

    @Test
    public void testTransactionCount() {

        assertTrue(transactionService.findAllByAccountNumber(new DecimalFormat("1234567980")).size() > 0,"No. of transactions is 0");

    }
}