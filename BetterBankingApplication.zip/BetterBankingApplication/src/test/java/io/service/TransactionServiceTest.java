package io.service;

import io.betterbanking.service.TransactionService;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TransactionServiceTest {

    @Test
    public void testTransactionCount() {

        TransactionService transactionService = new TransactionService();

        assertTrue(transactionService.listOfTransactions.size() > 0,"No. of transactions is 0");

    }
}