package io;

import io.betterbanking.web.TransactionController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BetterBankingApplicationTests {

//	@Autowired
//	private TransactionController transactionController;

//	BetterBankingApplicationTests(TransactionController transactionController) {
//		this.transactionController = transactionController;
//	}

	@Test
	void contextLoads() {
	}

}
